export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
}

export interface Food {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  type: 'veg' | 'non-veg';
  rating: number;
  preparationTime: number;
}

export interface CartItem {
  food: Food;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'preparing' | 'out-for-delivery' | 'delivered';
  createdAt: string;
  deliveryAddress: string;
  paymentMethod: string;
  paymentStatus: 'pending' | 'completed';
}