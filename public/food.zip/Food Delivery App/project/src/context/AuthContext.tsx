import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // Mock API call - in a real app, you'd call your backend
      if (email === 'user@example.com' && password === 'password') {
        const mockUser = {
          id: '1',
          name: 'John Doe',
          email: 'user@example.com',
          role: 'user'
        } as User;
        setUser(mockUser);
        localStorage.setItem('user', JSON.stringify(mockUser));
      } else if (email === 'admin@example.com' && password === 'password') {
        const mockAdmin = {
          id: '2',
          name: 'Admin User',
          email: 'admin@example.com',
          role: 'admin'
        } as User;
        setUser(mockAdmin);
        localStorage.setItem('user', JSON.stringify(mockAdmin));
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const signup = async (name: string, email: string, password: string) => {
    try {
      // Mock API call - in a real app, you'd call your backend
      const mockUser = {
        id: Date.now().toString(),
        name,
        email,
        role: 'user'
      } as User;
      setUser(mockUser);
      localStorage.setItem('user', JSON.stringify(mockUser));
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        signup,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};