import { Food, Order } from '../types';

export const foodItems: Food[] = [
  {
    id: '1',
    name: 'Margherita Pizza',
    description: 'Classic pizza with tomato sauce, mozzarella, and basil',
    price: 12.99,
    image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Pizza',
    type: 'veg',
    rating: 4.5,
    preparationTime: 25
  },
  {
    id: '2',
    name: 'Chicken Burger',
    description: 'Juicy chicken patty with lettuce, tomato, and special sauce',
    price: 8.99,
    image: 'https://images.pexels.com/photos/2983098/pexels-photo-2983098.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Burgers',
    type: 'non-veg',
    rating: 4.2,
    preparationTime: 15
  },
  {
    id: '3',
    name: 'Veggie Wrap',
    description: 'Fresh vegetables with hummus wrapped in a tortilla',
    price: 7.49,
    image: 'https://images.pexels.com/photos/2245673/pexels-photo-2245673.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Wraps',
    type: 'veg',
    rating: 4.0,
    preparationTime: 10
  },
  {
    id: '4',
    name: 'Chicken Biryani',
    description: 'Fragrant rice with tender chicken pieces and aromatic spices',
    price: 14.99,
    image: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Indian',
    type: 'non-veg',
    rating: 4.8,
    preparationTime: 30
  },
  {
    id: '5',
    name: 'Caesar Salad',
    description: 'Crisp romaine lettuce with Caesar dressing, croutons, and parmesan',
    price: 9.99,
    image: 'https://images.pexels.com/photos/1211887/pexels-photo-1211887.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Salads',
    type: 'veg',
    rating: 4.3,
    preparationTime: 10
  },
  {
    id: '6',
    name: 'Beef Steak',
    description: 'Tender beef steak cooked to perfection with sides',
    price: 22.99,
    image: 'https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Steaks',
    type: 'non-veg',
    rating: 4.7,
    preparationTime: 35
  },
  {
    id: '7',
    name: 'Mushroom Pasta',
    description: 'Creamy pasta with sautéed mushrooms and fresh herbs',
    price: 10.99,
    image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Pasta',
    type: 'veg',
    rating: 4.4,
    preparationTime: 20
  },
  {
    id: '8',
    name: 'Fish and Chips',
    description: 'Crispy battered fish with golden chips and tartar sauce',
    price: 13.49,
    image: 'https://images.pexels.com/photos/3298180/pexels-photo-3298180.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300',
    category: 'Seafood',
    type: 'non-veg',
    rating: 4.6,
    preparationTime: 25
  }
];

export const mockOrders: Order[] = [
  {
    id: 'ORD-1001',
    userId: '1',
    items: [
      { food: foodItems[0], quantity: 1 },
      { food: foodItems[4], quantity: 1 }
    ],
    totalAmount: foodItems[0].price + foodItems[4].price,
    status: 'delivered',
    createdAt: '2023-11-15T10:30:00Z',
    deliveryAddress: '123 Main St, City',
    paymentMethod: 'credit_card',
    paymentStatus: 'completed'
  },
  {
    id: 'ORD-1002',
    userId: '1',
    items: [
      { food: foodItems[1], quantity: 2 }
    ],
    totalAmount: foodItems[1].price * 2,
    status: 'preparing',
    createdAt: '2023-11-20T18:45:00Z',
    deliveryAddress: '123 Main St, City',
    paymentMethod: 'credit_card',
    paymentStatus: 'completed'
  }
];

export const foodCategories = [
  'All',
  'Pizza',
  'Burgers',
  'Wraps',
  'Indian',
  'Salads',
  'Steaks',
  'Pasta',
  'Seafood'
];