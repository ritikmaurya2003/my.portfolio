import React from 'react';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <Link to="/" className="text-xl font-bold text-orange-500">FoodExpress</Link>
            <p className="mt-3 text-gray-300 text-sm leading-relaxed">
              Delivering delicious food to your doorstep. Fresh ingredients, tasty meals, fast delivery.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/menu" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Menu
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/menu?category=Pizza" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Pizza
                </Link>
              </li>
              <li>
                <Link to="/menu?category=Burgers" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Burgers
                </Link>
              </li>
              <li>
                <Link to="/menu?category=Indian" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Indian
                </Link>
              </li>
              <li>
                <Link to="/menu?category=Salads" className="text-gray-300 hover:text-orange-500 transition-colors text-sm">
                  Salads
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 text-orange-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 text-sm">
                  123 Food Street, Cuisine City, FC 12345
                </span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="mr-2 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300 text-sm">(123) 456-7890</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 text-orange-500 flex-shrink-0" />
                <span className="text-gray-300 text-sm">info@foodexpress.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-10 pt-6">
          <p className="text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} FoodExpress. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;