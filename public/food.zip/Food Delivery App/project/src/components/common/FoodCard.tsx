import React from 'react';
import { Food } from '../../types';
import Button from './Button';
import { Clock, Star } from 'lucide-react';

interface FoodCardProps {
  food: Food;
  onAddToCart: () => void;
}

const FoodCard: React.FC<FoodCardProps> = ({ food, onAddToCart }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img 
          src={food.image} 
          alt={food.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-white px-2 py-1 rounded-full shadow-sm">
          <span className={`text-xs font-medium ${food.type === 'veg' ? 'text-green-600' : 'text-red-600'}`}>
            {food.type === 'veg' ? 'Veg' : 'Non-Veg'}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg text-gray-800 truncate">{food.name}</h3>
          <div className="flex items-center bg-green-50 px-2 py-1 rounded">
            <Star size={14} className="text-yellow-500 mr-1" />
            <span className="text-sm font-medium">{food.rating}</span>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{food.description}</p>
        
        <div className="flex items-center mb-3">
          <Clock size={16} className="text-gray-500 mr-1" />
          <span className="text-sm text-gray-500">{food.preparationTime} mins</span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="font-bold text-lg">${food.price.toFixed(2)}</span>
          <Button 
            variant="primary" 
            size="sm" 
            onClick={onAddToCart}
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FoodCard;