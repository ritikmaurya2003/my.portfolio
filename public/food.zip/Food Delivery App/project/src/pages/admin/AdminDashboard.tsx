import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  ShoppingBag, 
  PieChart, 
  Settings, 
  LogOut,
  Plus,
  Search,
  Edit2,
  Trash2
} from 'lucide-react';
import Button from '../../components/common/Button';
import { useAuth } from '../../context/AuthContext';
import { foodItems } from '../../data/mockData';
import { Food } from '../../types';

const AdminSidebar: React.FC<{ activePage: string }> = ({ activePage }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  const menuItems = [
    { icon: <LayoutDashboard size={20} />, text: 'Dashboard', link: '/admin' },
    { icon: <ShoppingBag size={20} />, text: 'Food Items', link: '/admin/food' },
    { icon: <Users size={20} />, text: 'Customers', link: '/admin/customers' },
    { icon: <PieChart size={20} />, text: 'Reports', link: '/admin/reports' },
    { icon: <Settings size={20} />, text: 'Settings', link: '/admin/settings' },
  ];
  
  return (
    <div className="bg-gray-800 text-white h-screen w-64 fixed left-0 overflow-y-auto">
      <div className="p-6">
        <Link to="/admin" className="text-xl font-bold flex items-center">
          <span className="text-orange-500">Food</span>
          <span>Express</span>
          <span className="ml-2 text-xs bg-orange-500 text-white px-2 py-1 rounded">Admin</span>
        </Link>
      </div>
      
      <nav className="mt-6">
        {menuItems.map((item) => (
          <Link
            key={item.text}
            to={item.link}
            className={`flex items-center px-6 py-3 ${
              activePage === item.text.toLowerCase()
                ? 'bg-gray-700 border-l-4 border-orange-500'
                : 'hover:bg-gray-700'
            }`}
          >
            <span className="mr-3">{item.icon}</span>
            <span>{item.text}</span>
          </Link>
        ))}
        
        <button
          onClick={handleLogout}
          className="flex items-center w-full px-6 py-3 text-gray-300 hover:bg-gray-700"
        >
          <LogOut size={20} className="mr-3" />
          <span>Logout</span>
        </button>
      </nav>
    </div>
  );
};

const AdminDashboard: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  
  // Redirect if not admin
  if (!isAuthenticated || user?.role !== 'admin') {
    navigate('/login');
    return null;
  }
  
  // Filter food items based on search query and type
  const filteredItems = foodItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || item.type === selectedType;
    return matchesSearch && matchesType;
  });
  
  // Mock statistics
  const statistics = [
    { label: 'Total Orders', value: '256', change: '+12%', icon: <ShoppingBag size={20} className="text-blue-500" /> },
    { label: 'Total Revenue', value: '$8,256', change: '+18%', icon: <PieChart size={20} className="text-green-500" /> },
    { label: 'Active Users', value: '3,652', change: '+7%', icon: <Users size={20} className="text-purple-500" /> },
    { label: 'Menu Items', value: `${foodItems.length}`, change: '+2', icon: <ShoppingBag size={20} className="text-orange-500" /> },
  ];
  
  return (
    <div className="bg-gray-100 min-h-screen">
      <AdminSidebar activePage="dashboard" />
      
      <div className="ml-64 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <div>
            <span className="mr-2 text-gray-600">Welcome, {user?.name}</span>
          </div>
        </div>
        
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statistics.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-gray-600 font-medium">{stat.label}</h3>
                <div className="p-2 rounded-full bg-gray-50">{stat.icon}</div>
              </div>
              <div className="flex items-end">
                <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                <p className={`ml-2 text-sm ${stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                  {stat.change}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Recent Orders */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Recent Orders</h2>
            <Link to="/admin/orders" className="text-orange-500 hover:text-orange-600 text-sm font-medium">
              View All
            </Link>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order ID
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-medium text-gray-800">ORD-1001</span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    John Doe
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm text-gray-500">
                    Nov 15, 2023
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap font-medium">
                    $22.98
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                      Delivered
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm">
                    <button className="text-blue-500 hover:text-blue-700 mr-2">
                      View
                    </button>
                  </td>
                </tr>
                <tr>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-medium text-gray-800">ORD-1002</span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    Jane Smith
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm text-gray-500">
                    Nov 20, 2023
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap font-medium">
                    $17.98
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-indigo-100 text-indigo-800 rounded-full">
                      Preparing
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm">
                    <button className="text-blue-500 hover:text-blue-700 mr-2">
                      View
                    </button>
                  </td>
                </tr>
                <tr>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-medium text-gray-800">ORD-1003</span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    Mike Johnson
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm text-gray-500">
                    Nov 22, 2023
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap font-medium">
                    $35.97
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
                      Pending
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap text-sm">
                    <button className="text-blue-500 hover:text-blue-700 mr-2">
                      View
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Food Management */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Food Management</h2>
            <Button variant="primary" size="sm" icon={<Plus size={18} />}>
              Add New Item
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-grow max-w-md">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search food items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
              </div>
            </div>
            
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="all">All Types</option>
              <option value="veg">Vegetarian</option>
              <option value="non-veg">Non-Vegetarian</option>
            </select>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Image
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredItems.map((food: Food) => (
                  <tr key={food.id}>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <img 
                        src={food.image} 
                        alt={food.name} 
                        className="w-12 h-12 object-cover rounded-md"
                      />
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-medium text-gray-800">{food.name}</span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {food.category}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        food.type === 'veg' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {food.type === 'veg' ? 'Vegetarian' : 'Non-Vegetarian'}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap font-medium">
                      ${food.price.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <button className="text-blue-500 hover:text-blue-700 mr-2">
                        <Edit2 size={16} />
                      </button>
                      <button className="text-red-500 hover:text-red-700">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;