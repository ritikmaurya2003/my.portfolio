import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, MapPin, Truck, Check } from 'lucide-react';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const CheckoutPage: React.FC = () => {
  const { items, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    // Delivery details
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    // Payment details
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: '',
  });
  const [paymentMethod, setPaymentMethod] = useState<'credit_card' | 'cash'>('credit_card');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };
  
  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.fullName) newErrors.fullName = 'Full name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    if (!formData.phone) newErrors.phone = 'Phone number is required';
    if (!formData.address) newErrors.address = 'Address is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.postalCode) newErrors.postalCode = 'Postal code is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    
    if (paymentMethod === 'credit_card') {
      if (!formData.cardNumber) newErrors.cardNumber = 'Card number is required';
      if (!formData.cardName) newErrors.cardName = 'Name on card is required';
      if (!formData.expiryDate) newErrors.expiryDate = 'Expiry date is required';
      if (!formData.cvv) newErrors.cvv = 'CVV is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleNextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    }
  };
  
  const handlePreviousStep = () => {
    setStep((prev) => Math.max(prev - 1, 1));
  };
  
  const handleSubmitOrder = async () => {
    setLoading(true);
    
    try {
      // Simulate API call to create order
      setTimeout(() => {
        const orderId = 'ORD-' + Math.floor(1000 + Math.random() * 9000);
        clearCart();
        navigate(`/order-success/${orderId}`);
      }, 1500);
    } catch (error) {
      console.error('Error creating order:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const subtotal = getTotalPrice();
  const deliveryFee = 2.99;
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + deliveryFee + tax;
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Checkout</h1>
        
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                step >= 1 ? 'bg-orange-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                <MapPin size={20} />
              </div>
              <div className={`h-1 w-24 ${step > 1 ? 'bg-orange-500' : 'bg-gray-200'}`}></div>
            </div>
            
            <div className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                step >= 2 ? 'bg-orange-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                <CreditCard size={20} />
              </div>
              <div className={`h-1 w-24 ${step > 2 ? 'bg-orange-500' : 'bg-gray-200'}`}></div>
            </div>
            
            <div className="flex items-center">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                step >= 3 ? 'bg-orange-500 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                <Check size={20} />
              </div>
            </div>
          </div>
          
          <div className="flex justify-center mt-2">
            <div className="text-sm font-medium w-32 text-center">
              Delivery Details
            </div>
            <div className="text-sm font-medium w-32 text-center">
              Payment Method
            </div>
            <div className="text-sm font-medium w-32 text-center">
              Confirmation
            </div>
          </div>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Form Section */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              {/* Step 1: Delivery Details */}
              {step === 1 && (
                <div>
                  <h2 className="text-xl font-bold text-gray-800 mb-6">Delivery Details</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      id="fullName"
                      label="Full Name"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      error={errors.fullName}
                      required
                    />
                    <Input
                      id="email"
                      label="Email Address"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      error={errors.email}
                      required
                    />
                    <Input
                      id="phone"
                      label="Phone Number"
                      value={formData.phone}
                      onChange={handleInputChange}
                      error={errors.phone}
                      required
                    />
                    <Input
                      id="address"
                      label="Address"
                      value={formData.address}
                      onChange={handleInputChange}
                      error={errors.address}
                      required
                    />
                    <Input
                      id="city"
                      label="City"
                      value={formData.city}
                      onChange={handleInputChange}
                      error={errors.city}
                      required
                    />
                    <Input
                      id="postalCode"
                      label="Postal Code"
                      value={formData.postalCode}
                      onChange={handleInputChange}
                      error={errors.postalCode}
                      required
                    />
                  </div>
                  
                  <div className="mt-8">
                    <Button
                      variant="primary"
                      size="lg"
                      onClick={handleNextStep}
                    >
                      Next: Payment Method
                    </Button>
                  </div>
                </div>
              )}
              
              {/* Step 2: Payment Method */}
              {step === 2 && (
                <div>
                  <h2 className="text-xl font-bold text-gray-800 mb-6">Payment Method</h2>
                  
                  <div className="mb-6">
                    <div className="flex space-x-4">
                      <label className={`flex-1 border rounded-lg p-4 cursor-pointer ${
                        paymentMethod === 'credit_card' 
                          ? 'border-orange-500 bg-orange-50' 
                          : 'border-gray-200'
                      }`}>
                        <input
                          type="radio"
                          name="paymentMethod"
                          value="credit_card"
                          checked={paymentMethod === 'credit_card'}
                          onChange={() => setPaymentMethod('credit_card')}
                          className="sr-only"
                        />
                        <div className="flex items-center">
                          <div className="flex-shrink-0 mr-3">
                            <CreditCard size={24} className={paymentMethod === 'credit_card' ? 'text-orange-500' : 'text-gray-400'} />
                          </div>
                          <div>
                            <p className="font-medium">Credit Card</p>
                            <p className="text-sm text-gray-500">Pay securely with your credit card</p>
                          </div>
                        </div>
                      </label>
                      
                      <label className={`flex-1 border rounded-lg p-4 cursor-pointer ${
                        paymentMethod === 'cash' 
                          ? 'border-orange-500 bg-orange-50' 
                          : 'border-gray-200'
                      }`}>
                        <input
                          type="radio"
                          name="paymentMethod"
                          value="cash"
                          checked={paymentMethod === 'cash'}
                          onChange={() => setPaymentMethod('cash')}
                          className="sr-only"
                        />
                        <div className="flex items-center">
                          <div className="flex-shrink-0 mr-3">
                            <Truck size={24} className={paymentMethod === 'cash' ? 'text-orange-500' : 'text-gray-400'} />
                          </div>
                          <div>
                            <p className="font-medium">Cash on Delivery</p>
                            <p className="text-sm text-gray-500">Pay when your order arrives</p>
                          </div>
                        </div>
                      </label>
                    </div>
                  </div>
                  
                  {paymentMethod === 'credit_card' && (
                    <div className="space-y-4">
                      <Input
                        id="cardNumber"
                        label="Card Number"
                        placeholder="1234 5678 9012 3456"
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        error={errors.cardNumber}
                        required
                      />
                      <Input
                        id="cardName"
                        label="Name on Card"
                        placeholder="John Doe"
                        value={formData.cardName}
                        onChange={handleInputChange}
                        error={errors.cardName}
                        required
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <Input
                          id="expiryDate"
                          label="Expiry Date"
                          placeholder="MM/YY"
                          value={formData.expiryDate}
                          onChange={handleInputChange}
                          error={errors.expiryDate}
                          required
                        />
                        <Input
                          id="cvv"
                          label="CVV"
                          placeholder="123"
                          value={formData.cvv}
                          onChange={handleInputChange}
                          error={errors.cvv}
                          required
                        />
                      </div>
                    </div>
                  )}
                  
                  <div className="mt-8 flex justify-between">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={handlePreviousStep}
                    >
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      size="lg"
                      onClick={handleNextStep}
                    >
                      Next: Confirmation
                    </Button>
                  </div>
                </div>
              )}
              
              {/* Step 3: Confirmation */}
              {step === 3 && (
                <div>
                  <h2 className="text-xl font-bold text-gray-800 mb-6">Order Confirmation</h2>
                  
                  <div className="space-y-6">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-800 mb-2">Delivery Details</h3>
                      <p>{formData.fullName}</p>
                      <p>{formData.email}</p>
                      <p>{formData.phone}</p>
                      <p>{formData.address}</p>
                      <p>{formData.city}, {formData.postalCode}</p>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-800 mb-2">Payment Method</h3>
                      {paymentMethod === 'credit_card' ? (
                        <div>
                          <p>Credit Card</p>
                          <p>**** **** **** {formData.cardNumber.slice(-4)}</p>
                        </div>
                      ) : (
                        <p>Cash on Delivery</p>
                      )}
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-800 mb-2">Order Summary</h3>
                      <ul className="divide-y divide-gray-200">
                        {items.map((item) => (
                          <li key={item.food.id} className="py-3 flex justify-between">
                            <div>
                              <span className="font-medium">{item.quantity}x </span>
                              {item.food.name}
                            </div>
                            <span>${(item.food.price * item.quantity).toFixed(2)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  
                  <div className="mt-8 flex justify-between">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={handlePreviousStep}
                    >
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      size="lg"
                      onClick={handleSubmitOrder}
                      disabled={loading}
                    >
                      {loading ? 'Processing...' : 'Place Order'}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Order Summary</h2>
              
              <ul className="space-y-3 mb-6">
                {items.map((item) => (
                  <li key={item.food.id} className="flex justify-between">
                    <div>
                      <span className="font-medium">{item.quantity}x </span>
                      <span className="text-gray-700">{item.food.name}</span>
                    </div>
                    <span className="font-medium">${(item.food.price * item.quantity).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
              
              <div className="border-t border-gray-200 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="font-medium">${deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span className="font-medium">${tax.toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between">
                  <span className="text-lg font-bold">Total</span>
                  <span className="text-lg font-bold">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;