import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ChevronRight, ShoppingBag } from 'lucide-react';
import Button from '../components/common/Button';
import { useAuth } from '../context/AuthContext';
import { mockOrders } from '../data/mockData';

const OrderStatusBadge: React.FC<{ status: string }> = ({ status }) => {
  let bgColor = '';
  let textColor = '';
  
  switch (status) {
    case 'pending':
      bgColor = 'bg-yellow-100';
      textColor = 'text-yellow-800';
      break;
    case 'confirmed':
      bgColor = 'bg-blue-100';
      textColor = 'text-blue-800';
      break;
    case 'preparing':
      bgColor = 'bg-indigo-100';
      textColor = 'text-indigo-800';
      break;
    case 'out-for-delivery':
      bgColor = 'bg-purple-100';
      textColor = 'text-purple-800';
      break;
    case 'delivered':
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
      break;
    default:
      bgColor = 'bg-gray-100';
      textColor = 'text-gray-800';
  }
  
  return (
    <span className={`${bgColor} ${textColor} px-3 py-1 rounded-full text-xs font-medium capitalize`}>
      {status.replace(/-/g, ' ')}
    </span>
  );
};

const OrdersPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  // If user is not authenticated, show login prompt
  if (!isAuthenticated) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={32} className="text-orange-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">You need to be logged in</h2>
          <p className="text-gray-600 mb-8">
            Please sign in to view your order history and track current orders.
          </p>
          <Link to="/login?redirect=orders">
            <Button variant="primary" size="lg">
              Sign In
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  // If no orders, show empty state
  if (mockOrders.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={32} className="text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">No orders yet</h2>
          <p className="text-gray-600 mb-8">
            You haven't placed any orders yet. Explore our menu and place your first order!
          </p>
          <Link to="/menu">
            <Button variant="primary" size="lg">
              Browse Menu
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Your Orders</h1>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="divide-y divide-gray-200">
            {mockOrders.map((order) => (
              <div key={order.id} className="p-6">
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-800">{order.id}</h2>
                    <p className="text-sm text-gray-500">
                      {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="mt-2 md:mt-0">
                    <OrderStatusBadge status={order.status} />
                  </div>
                </div>
                
                <div className="border-t border-b border-gray-100 py-4 my-4">
                  <ul className="divide-y divide-gray-100">
                    {order.items.map((item, index) => (
                      <li key={index} className="py-3 flex items-center justify-between">
                        <div className="flex items-center">
                          <img
                            src={item.food.image}
                            alt={item.food.name}
                            className="w-12 h-12 object-cover rounded-md mr-4"
                          />
                          <div>
                            <p className="font-medium">{item.food.name}</p>
                            <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                          </div>
                        </div>
                        <span className="font-medium">${(item.food.price * item.quantity).toFixed(2)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex flex-col md:flex-row justify-between">
                  <div>
                    <p className="text-gray-600 font-medium mb-1">Delivered to</p>
                    <p className="text-sm text-gray-500">{order.deliveryAddress}</p>
                  </div>
                  
                  <div className="mt-4 md:mt-0">
                    <p className="text-gray-600 font-medium mb-1">Total Amount</p>
                    <p className="text-xl font-semibold">${order.totalAmount.toFixed(2)}</p>
                  </div>
                  
                  <div className="mt-4 md:mt-0 flex items-center">
                    <Link
                      to={`/order/${order.id}`}
                      className="text-orange-500 hover:text-orange-600 flex items-center font-medium"
                    >
                      View Details
                      <ChevronRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </div>
                
                {order.status === 'preparing' && (
                  <div className="mt-4 bg-blue-50 p-3 rounded-md flex items-start">
                    <Clock size={20} className="text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-blue-700">
                      Your order is being prepared! It will be out for delivery in 15-20 minutes.
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrdersPage;