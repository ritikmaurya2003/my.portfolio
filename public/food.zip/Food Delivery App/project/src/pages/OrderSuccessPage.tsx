import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CheckCircle, Clock, MapPin, Truck, Coffee } from 'lucide-react';
import Button from '../components/common/Button';

const OrderSuccessPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const [orderStatus, setOrderStatus] = useState('confirmed');
  const [progress, setProgress] = useState(25);
  
  // Simulate order progress
  useEffect(() => {
    const timer = setTimeout(() => {
      setOrderStatus('preparing');
      setProgress(50);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-green-50 p-6 border-b border-green-100">
            <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start">
              <CheckCircle size={48} className="text-green-500 mr-4 mb-3 sm:mb-0" />
              <div className="text-center sm:text-left">
                <h1 className="text-2xl font-bold text-gray-800">Order Placed Successfully!</h1>
                <p className="text-gray-600 mt-1">
                  Thank you for your order. We've received your order and will start preparing it right away.
                </p>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-2">Order ID: {orderId}</h2>
              <p className="text-gray-600">
                We've sent a confirmation email with your order details.
              </p>
            </div>
            
            {/* Order Tracking */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Track Your Order</h3>
              
              <div className="relative">
                {/* Progress bar */}
                <div className="overflow-hidden h-2 mb-6 text-xs flex rounded bg-gray-200">
                  <div 
                    style={{ width: `${progress}%` }} 
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500 transition-all duration-1000"
                  ></div>
                </div>
                
                {/* Steps */}
                <div className="flex justify-between">
                  <div className="text-center">
                    <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${
                      orderStatus === 'confirmed' || orderStatus === 'preparing' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'
                    }`}>
                      <CheckCircle size={20} />
                    </div>
                    <div className="text-sm font-medium mt-2">Confirmed</div>
                  </div>
                  
                  <div className="text-center">
                    <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${
                      orderStatus === 'preparing' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'
                    }`}>
                      <Coffee size={20} />
                    </div>
                    <div className="text-sm font-medium mt-2">Preparing</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto rounded-full flex items-center justify-center bg-gray-200 text-gray-500">
                      <Truck size={20} />
                    </div>
                    <div className="text-sm font-medium mt-2">On the way</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto rounded-full flex items-center justify-center bg-gray-200 text-gray-500">
                      <MapPin size={20} />
                    </div>
                    <div className="text-sm font-medium mt-2">Delivered</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Estimated Delivery */}
            <div className="bg-orange-50 rounded-lg p-4 mb-8 flex items-start">
              <Clock size={24} className="text-orange-500 mr-3 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-800 mb-1">Estimated Delivery Time</h3>
                <p className="text-gray-600">
                  Your order is estimated to arrive in 30-45 minutes.
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  We'll update you when your order is on the way!
                </p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/orders">
                <Button variant="primary">
                  Track Order Status
                </Button>
              </Link>
              <Link to="/menu">
                <Button variant="outline">
                  Continue Shopping
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccessPage;