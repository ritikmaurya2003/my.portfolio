import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';
import { Food } from '../types';
import FoodCard from '../components/common/FoodCard';
import Button from '../components/common/Button';
import { foodItems, foodCategories } from '../data/mockData';
import { useCart } from '../context/CartContext';

const MenuPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState<'all' | 'veg' | 'non-veg'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'price-low' | 'price-high' | 'rating'>('name');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const { addToCart } = useCart();
  
  // Get category from URL on initial load
  useEffect(() => {
    const categoryParam = searchParams.get('category');
    if (categoryParam && foodCategories.includes(categoryParam)) {
      setSelectedCategory(categoryParam);
    }
  }, [searchParams]);
  
  // Filter food items based on search, category, and type
  const filteredItems = foodItems.filter((item) => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    
    const matchesType = 
      selectedType === 'all' || 
      (selectedType === 'veg' && item.type === 'veg') || 
      (selectedType === 'non-veg' && item.type === 'non-veg');
    
    return matchesSearch && matchesCategory && matchesType;
  });
  
  // Sort the filtered items based on the selected sort option
  const sortedItems = [...filteredItems].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      default:
        return 0;
    }
  });
  
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    if (category !== 'All') {
      setSearchParams({ category });
    } else {
      setSearchParams({});
    }
  };
  
  return (
    <div className="bg-gray-50 min-h-screen pb-12">
      <div className="bg-orange-500 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white mb-6">Our Menu</h1>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Search for food..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-2/3 pl-10 pr-12 py-3 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-orange-300"
            />
            <Search className="absolute left-3 top-3.5 text-gray-400" size={20} />
            <button 
              className="md:hidden absolute right-3 top-3 text-gray-500"
              onClick={() => setIsFilterOpen(!isFilterOpen)}
            >
              <SlidersHorizontal size={20} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-64 bg-white rounded-lg shadow-md p-4 h-fit sticky top-24">
            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                <Filter size={18} className="mr-2" />
                Categories
              </h3>
              <div className="space-y-2">
                {foodCategories.map((category) => (
                  <button
                    key={category}
                    onClick={() => handleCategorySelect(category)}
                    className={`block w-full text-left px-3 py-2 rounded-md text-sm ${
                      selectedCategory === category
                        ? 'bg-orange-100 text-orange-700 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 mb-3">Type</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="type"
                    checked={selectedType === 'all'}
                    onChange={() => setSelectedType('all')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                  />
                  <span className="ml-2 text-sm text-gray-700">All</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="type"
                    checked={selectedType === 'veg'}
                    onChange={() => setSelectedType('veg')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                  />
                  <span className="ml-2 text-sm text-gray-700">Vegetarian</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="type"
                    checked={selectedType === 'non-veg'}
                    onChange={() => setSelectedType('non-veg')}
                    className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                  />
                  <span className="ml-2 text-sm text-gray-700">Non-Vegetarian</span>
                </label>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-800 mb-3">Sort By</h3>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="block w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring focus:ring-orange-200 focus:ring-opacity-50 text-sm"
              >
                <option value="name">Name (A-Z)</option>
                <option value="price-low">Price (Low to High)</option>
                <option value="price-high">Price (High to Low)</option>
                <option value="rating">Rating</option>
              </select>
            </div>
          </div>
          
          {/* Filters - Mobile */}
          {isFilterOpen && (
            <div className="md:hidden fixed inset-0 z-50 bg-gray-900 bg-opacity-50 backdrop-blur-sm overflow-y-auto">
              <div className="bg-white m-4 rounded-lg shadow-xl p-5 max-w-sm mx-auto">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold text-lg">Filters</h3>
                  <button onClick={() => setIsFilterOpen(false)}>
                    <X size={20} />
                  </button>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-800 mb-3">Categories</h3>
                  <div className="space-y-2">
                    {foodCategories.map((category) => (
                      <button
                        key={category}
                        onClick={() => {
                          handleCategorySelect(category);
                          setIsFilterOpen(false);
                        }}
                        className={`block w-full text-left px-3 py-2 rounded-md text-sm ${
                          selectedCategory === category
                            ? 'bg-orange-100 text-orange-700 font-medium'
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-800 mb-3">Type</h3>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="mobile-type"
                        checked={selectedType === 'all'}
                        onChange={() => setSelectedType('all')}
                        className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                      />
                      <span className="ml-2 text-sm text-gray-700">All</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="mobile-type"
                        checked={selectedType === 'veg'}
                        onChange={() => setSelectedType('veg')}
                        className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                      />
                      <span className="ml-2 text-sm text-gray-700">Vegetarian</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="mobile-type"
                        checked={selectedType === 'non-veg'}
                        onChange={() => setSelectedType('non-veg')}
                        className="h-4 w-4 text-orange-500 focus:ring-orange-400"
                      />
                      <span className="ml-2 text-sm text-gray-700">Non-Vegetarian</span>
                    </label>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-800 mb-3">Sort By</h3>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="block w-full mt-1 rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring focus:ring-orange-200 focus:ring-opacity-50 text-sm"
                  >
                    <option value="name">Name (A-Z)</option>
                    <option value="price-low">Price (Low to High)</option>
                    <option value="price-high">Price (High to Low)</option>
                    <option value="rating">Rating</option>
                  </select>
                </div>
                
                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedCategory('All');
                      setSelectedType('all');
                      setSortBy('name');
                      setIsFilterOpen(false);
                    }}
                  >
                    Reset
                  </Button>
                  <Button
                    variant="primary"
                    onClick={() => setIsFilterOpen(false)}
                  >
                    Apply Filters
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Food items grid */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-800">
                {sortedItems.length} {sortedItems.length === 1 ? 'item' : 'items'} found
              </h2>
              <div className="hidden md:block">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring focus:ring-orange-200 focus:ring-opacity-50 text-sm"
                >
                  <option value="name">Sort by: Name (A-Z)</option>
                  <option value="price-low">Sort by: Price (Low to High)</option>
                  <option value="price-high">Sort by: Price (High to Low)</option>
                  <option value="rating">Sort by: Rating</option>
                </select>
              </div>
            </div>
            
            {sortedItems.length === 0 ? (
              <div className="text-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-gray-400 mb-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.182 16.318A4.486 4.486 0 0 0 12.016 15a4.486 4.486 0 0 0-3.198 1.318M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75Zm-.375 0h.008v.015h-.008V9.75Z" />
                </svg>
                <h3 className="text-lg font-medium text-gray-900">No items found</h3>
                <p className="mt-1 text-gray-500">Try adjusting your search or filter to find what you're looking for.</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedType('all');
                    setSearchParams({});
                  }}
                >
                  Clear filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedItems.map((food) => (
                  <FoodCard 
                    key={food.id}
                    food={food}
                    onAddToCart={() => addToCart(food)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuPage;