import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faDownload, faEnvelope } from '@fortawesome/free-solid-svg-icons'
import Button from '../components/ui/Button'
import Card from '../components/ui/Card'
import { toast } from 'react-toastify'

const Resources = ({ textEnter, textLeave }) => {
  // Email confirmation modal
  const [showModal, setShowModal] = useState(false)
  const [selectedResource, setSelectedResource] = useState(null)
  const [email, setEmail] = useState('')
  
  // Free resources data
  const freeResources = [
    {
      id: 1,
      title: 'React Component Guide',
      description: 'A comprehensive guide to building reusable React components with best practices and examples.',
      image: 'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      downloadLink: '#'
    },
    {
      id: 2,
      title: 'CSS Grid Cheatsheet',
      description: 'A visual guide to CSS Grid layout with common patterns and responsive design examples.',
      image: 'https://images.pexels.com/photos/6444/pencil-typography-black-design.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      downloadLink: '#'
    },
    {
      id: 3,
      title: 'Web Performance Checklist',
      description: 'A comprehensive checklist for optimizing web performance and improving user experience.',
      image: 'https://images.pexels.com/photos/207580/pexels-photo-207580.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      downloadLink: '#'
    }
  ]
  
  // Premium resources data
  const premiumResources = [
    {
      id: 4,
      title: 'Ultimate Frontend Development Bundle',
      description: 'A complete collection of tools, templates, and guides for modern frontend development.',
      image: 'https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      price: 'Premium'
    },
    {
      id: 5,
      title: 'React & Node.js E-commerce Starter',
      description: 'A fully functional e-commerce starter kit with React frontend and Node.js backend.',
      image: 'https://images.pexels.com/photos/3888151/pexels-photo-3888151.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      price: 'Premium'
    },
    {
      id: 6,
      title: 'Advanced CSS Animation Course',
      description: 'Learn to create stunning CSS animations for modern web applications.',
      image: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      price: 'Premium'
    }
  ]
  
  // Handle resource download
  const handleDownload = (resource) => {
    window.open(resource.downloadLink, '_blank')
    toast.success(`Downloaded: ${resource.title}`)
  }
  
  // Handle premium resource click
  const handlePremiumResource = (resource) => {
    setSelectedResource(resource)
    setShowModal(true)
  }
  
  // Handle email submission
  const handleEmailSubmit = (e) => {
    e.preventDefault()
    
    // Simulate email sending
    toast.success(`${selectedResource.title} has been sent to ${email}`)
    setShowModal(false)
    setEmail('')
  }
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const resourceVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1
    }
  }
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-24 pb-16 px-4 sm:px-6"
    >
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Resources</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Access premium templates, guides, and development resources. Free and premium materials to help you in your development journey.
          </p>
        </motion.div>
        
        {/* Free Resources */}
        <section className="mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-3xl font-bold mb-8"
          >
            Free Resources
          </motion.h2>
          
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {freeResources.map((resource) => (
              <motion.div
                key={resource.id}
                variants={resourceVariants}
              >
                <Card 
                  className="h-full flex flex-col"
                  onMouseEnter={textEnter}
                  onMouseLeave={textLeave}
                >
                  <div className="relative overflow-hidden rounded-t-2xl h-48">
                    <img 
                      src={resource.image} 
                      alt={resource.title} 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                    <p className="text-gray-400 mb-6 flex-grow">{resource.description}</p>
                    <Button
                      variant="primary"
                      onClick={() => handleDownload(resource)}
                      onMouseEnter={textEnter}
                      onMouseLeave={textLeave}
                      fullWidth
                    >
                      <FontAwesomeIcon icon={faDownload} className="mr-2" />
                      Download
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </section>
        
        {/* Premium Resources */}
        <section>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold mb-8"
          >
            Premium Resources
          </motion.h2>
          
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {premiumResources.map((resource) => (
              <motion.div
                key={resource.id}
                variants={resourceVariants}
              >
                <Card 
                  className="h-full flex flex-col"
                  onMouseEnter={textEnter}
                  onMouseLeave={textLeave}
                >
                  <div className="relative overflow-hidden rounded-t-2xl h-48">
                    <img 
                      src={resource.image} 
                      alt={resource.title} 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute top-0 right-0 bg-red-500 py-1 px-3 rounded-bl-lg">
                      {resource.price}
                    </div>
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                    <p className="text-gray-400 mb-6 flex-grow">{resource.description}</p>
                    <Button
                      variant="primary"
                      onClick={() => handlePremiumResource(resource)}
                      onMouseEnter={textEnter}
                      onMouseLeave={textLeave}
                      fullWidth
                    >
                      <FontAwesomeIcon icon={faEnvelope} className="mr-2" />
                      Send to Email
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </section>
        
        {/* Email Modal */}
        <AnimatePresence>
          {showModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
              onClick={() => setShowModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="glass p-8 rounded-2xl max-w-md w-full"
                onClick={(e) => e.stopPropagation()}
                onMouseEnter={textEnter}
                onMouseLeave={textLeave}
              >
                <h3 className="text-2xl font-semibold mb-4">Send Resource to Email</h3>
                <p className="text-gray-300 mb-6">
                  Enter your email address to receive <strong>{selectedResource?.title}</strong>
                </p>
                
                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full bg-black bg-opacity-40 rounded-lg border border-gray-700 py-3 px-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-white focus:border-transparent"
                      placeholder="your@email.com"
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <Button
                      type="submit"
                      onMouseEnter={textEnter}
                      onMouseLeave={textLeave}
                      fullWidth
                    >
                      Send
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => setShowModal(false)}
                      onMouseEnter={textEnter}
                      onMouseLeave={textLeave}
                      fullWidth
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}

export default Resources