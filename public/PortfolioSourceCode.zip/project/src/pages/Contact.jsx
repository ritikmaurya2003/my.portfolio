import { useState } from 'react'
import { motion } from 'framer-motion'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faLocationDot, faPhone } from '@fortawesome/free-solid-svg-icons'
import { faGithub, faLinkedin, faTwitter } from '@fortawesome/free-brands-svg-icons'
import Button from '../components/ui/Button'
import { toast } from 'react-toastify'

const Contact = ({ textEnter, textLeave }) => {
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  
  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }
  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    setTimeout(() => {
      toast.success("Message sent successfully! I'll get back to you soon.")
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      })
      setIsSubmitting(false)
    }, 1500)
  }
  
  // Contact information
  const contactInfo = [
    {
      icon: faEnvelope,
      title: 'Email',
      value: 'contact@ritik.com',
      link: 'mailto:contact@ritik.com'
    },
    {
      icon: faPhone,
      title: 'Phone',
      value: '+1 (123) 456-7890',
      link: 'tel:+11234567890'
    },
    {
      icon: faLocationDot,
      title: 'Location',
      value: 'San Francisco, CA',
      link: null
    }
  ]
  
  // Social media links
  const socialLinks = [
    {
      icon: faGithub,
      title: 'GitHub',
      link: 'https://github.com'
    },
    {
      icon: faLinkedin,
      title: 'LinkedIn',
      link: 'https://linkedin.com'
    },
    {
      icon: faTwitter,
      title: 'Twitter',
      link: 'https://twitter.com'
    }
  ]
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-24 pb-16 px-4 sm:px-6"
    >
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Contact Me</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Have a question or want to work together? Reach out to me using the form below.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="glass p-8 rounded-2xl mb-8" onMouseEnter={textEnter} onMouseLeave={textLeave}>
              <h2 className="text-2xl font-semibold mb-6">Get In Touch</h2>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-start">
                    <div className="bg-white bg-opacity-10 p-3 rounded-full mr-4">
                      <FontAwesomeIcon icon={info.icon} />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium">{info.title}</h3>
                      {info.link ? (
                        <a 
                          href={info.link} 
                          className="text-gray-300 hover:text-white transition-colors"
                        >
                          {info.value}
                        </a>
                      ) : (
                        <p className="text-gray-300">{info.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="glass p-8 rounded-2xl" onMouseEnter={textEnter} onMouseLeave={textLeave}>
              <h2 className="text-2xl font-semibold mb-6">Connect</h2>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white bg-opacity-10 p-4 rounded-full text-white hover:bg-opacity-20 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onMouseEnter={textEnter}
                    onMouseLeave={textLeave}
                    aria-label={social.title}
                  >
                    <FontAwesomeIcon icon={social.icon} size="lg" />
                  </motion.a>
                ))}
              </div>
              
              <p className="mt-6 text-gray-400">
                Feel free to connect with me on social media or check out my work.
              </p>
            </div>
          </motion.div>
          
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass p-8 rounded-2xl"
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            <h2 className="text-2xl font-semibold mb-6">Send Me a Message</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full bg-black bg-opacity-40 rounded-lg border border-gray-700 py-3 px-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-white focus:border-transparent"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full bg-black bg-opacity-40 rounded-lg border border-gray-700 py-3 px-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-white focus:border-transparent"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full bg-black bg-opacity-40 rounded-lg border border-gray-700 py-3 px-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-white focus:border-transparent"
                  placeholder="Project Inquiry"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows="5"
                  className="w-full bg-black bg-opacity-40 rounded-lg border border-gray-700 py-3 px-4 text-white placeholder-gray-500 focus:ring-2 focus:ring-white focus:border-transparent resize-none"
                  placeholder="Your message here..."
                ></textarea>
              </div>
              
              <Button
                type="submit"
                fullWidth
                disabled={isSubmitting}
                onMouseEnter={textEnter}
                onMouseLeave={textLeave}
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}

export default Contact