import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'

const Projects = ({ textEnter, textLeave }) => {
  // State for filter
  const [filter, setFilter] = useState('all')
  
  // Project data
  const projects = [
    {
      id: 1,
      title: 'E-Commerce Platform',
      description: 'A full-featured e-commerce platform with product management, cart functionality, and secure checkout.',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'web',
      tech: ['React', 'Node.js', 'MongoDB', 'Express', 'Stripe'],
      link: '#'
    },
    {
      id: 2,
      title: 'Task Management App',
      description: 'A collaborative task management application with real-time updates and team workspaces.',
      image: 'https://images.pexels.com/photos/6956903/pexels-photo-6956903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'web',
      tech: ['Vue.js', 'Firebase', 'Tailwind CSS'],
      link: '#'
    },
    {
      id: 3,
      title: 'Fitness Tracker',
      description: 'Mobile app for tracking workouts, nutrition, and fitness progress with personalized insights.',
      image: 'https://images.pexels.com/photos/4498362/pexels-photo-4498362.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'mobile',
      tech: ['React Native', 'Redux', 'Node.js', 'MongoDB'],
      link: '#'
    },
    {
      id: 4,
      title: 'Corporate Website',
      description: 'A modern, responsive website for a financial services company with custom CMS integration.',
      image: 'https://images.pexels.com/photos/6476258/pexels-photo-6476258.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'web',
      tech: ['Next.js', 'Strapi', 'Tailwind CSS', 'Framer Motion'],
      link: '#'
    },
    {
      id: 5,
      title: 'Smart Home Dashboard',
      description: 'IoT dashboard for monitoring and controlling smart home devices with data visualization.',
      image: 'https://images.pexels.com/photos/1571457/pexels-photo-1571457.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'iot',
      tech: ['React', 'D3.js', 'Node.js', 'WebSockets', 'MQTT'],
      link: '#'
    },
    {
      id: 6,
      title: 'Portfolio Theme',
      description: 'Premium portfolio theme for creative professionals with customizable sections and animations.',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'design',
      tech: ['HTML', 'CSS', 'JavaScript', 'GSAP'],
      link: '#'
    }
  ]
  
  // Filter projects based on selected category
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter)
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const projectVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.4
      }
    }
  }
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-24 pb-16 px-4 sm:px-6"
    >
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">My Projects</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            A showcase of my work across web, mobile, IoT and design projects.
          </p>
        </motion.div>
        
        {/* Filter Buttons */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          <Button 
            variant={filter === 'all' ? 'primary' : 'secondary'}
            onClick={() => setFilter('all')}
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            All Projects
          </Button>
          <Button 
            variant={filter === 'web' ? 'primary' : 'secondary'}
            onClick={() => setFilter('web')}
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            Web
          </Button>
          <Button 
            variant={filter === 'mobile' ? 'primary' : 'secondary'}
            onClick={() => setFilter('mobile')}
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            Mobile
          </Button>
          <Button 
            variant={filter === 'iot' ? 'primary' : 'secondary'}
            onClick={() => setFilter('iot')}
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            IoT
          </Button>
          <Button 
            variant={filter === 'design' ? 'primary' : 'secondary'}
            onClick={() => setFilter('design')}
            onMouseEnter={textEnter}
            onMouseLeave={textLeave}
          >
            Design
          </Button>
        </motion.div>
        
        {/* Projects Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={filter}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredProjects.map((project) => (
              <motion.div 
                key={project.id}
                variants={projectVariants}
                layout
              >
                <Card 
                  className="h-full flex flex-col"
                  onMouseEnter={textEnter}
                  onMouseLeave={textLeave}
                >
                  <div className="relative overflow-hidden rounded-t-2xl aspect-video">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" 
                    />
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-gray-400 mb-4 flex-grow">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tech.map((tech, index) => (
                        <span key={index} className="text-xs bg-white bg-opacity-10 px-2 py-1 rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                    <a 
                      href={project.link} 
                      className="mt-auto text-center glass py-2 px-4 rounded-full hover:bg-white hover:bg-opacity-10 transition-colors"
                    >
                      View Project
                    </a>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
        
        {filteredProjects.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className="text-gray-400">No projects found in this category.</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  )
}

export default Projects