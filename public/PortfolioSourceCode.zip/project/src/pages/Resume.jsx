import { motion } from 'framer-motion'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faDownload, faExternalLinkAlt } from '@fortawesome/free-solid-svg-icons'
import Button from '../components/ui/Button'

const Resume = ({ textEnter, textLeave }) => {
  // Resume sections data
  const resumeSections = [
    {
      title: 'Professional Summary',
      content: 'Innovative and deadline-driven Full Stack Developer with 6+ years of experience designing and developing user-centered digital experiences from initial concept to final, polished deliverable. Proficient in modern JavaScript frameworks, server technologies, and responsive design principles.'
    },
    {
      title: 'Work Experience',
      items: [
        {
          title: 'Senior Full Stack Developer',
          company: 'TechGlobe',
          period: 'Jan 2021 - Present',
          duties: [
            'Led development teams in delivering complex web applications',
            'Architected microservices infrastructure using Node.js and AWS',
            'Implemented CI/CD pipelines for automated testing and deployment',
            'Optimized database queries resulting in 65% improved performance'
          ]
        },
        {
          title: 'Frontend Developer',
          company: 'InnovateCorp',
          period: 'Mar 2019 - Dec 2020',
          duties: [
            'Developed responsive user interfaces with React and Redux',
            'Collaborated with UX/UI designers to implement design systems',
            'Maintained and improved existing codebases',
            'Participated in code reviews and mentored junior developers'
          ]
        }
      ]
    },
    {
      title: 'Education',
      items: [
        {
          title: 'Master of Computer Science',
          institution: 'Stanford University',
          period: '2018 - 2020'
        },
        {
          title: 'Bachelor of Technology in Computer Science',
          institution: 'Massachusetts Institute of Technology',
          period: '2014 - 2018'
        }
      ]
    },
    {
      title: 'Skills',
      categories: [
        {
          name: 'Programming Languages',
          skills: ['JavaScript (ES6+)', 'TypeScript', 'Python', 'Java', 'C#']
        },
        {
          name: 'Frontend',
          skills: ['React', 'Vue.js', 'Next.js', 'Angular', 'HTML5', 'CSS3', 'SCSS', 'TailwindCSS']
        },
        {
          name: 'Backend',
          skills: ['Node.js', 'Express', 'Django', 'Spring Boot', 'ASP.NET Core']
        },
        {
          name: 'Databases',
          skills: ['MongoDB', 'PostgreSQL', 'MySQL', 'Firebase', 'Redis']
        },
        {
          name: 'DevOps & Tools',
          skills: ['Git', 'Docker', 'Kubernetes', 'AWS', 'CI/CD', 'Jest', 'Webpack']
        }
      ]
    },
    {
      title: 'Certifications',
      items: [
        {
          title: 'AWS Certified Solutions Architect',
          issuer: 'Amazon Web Services',
          period: '2022'
        },
        {
          title: 'Google Professional Cloud Developer',
          issuer: 'Google Cloud',
          period: '2021'
        }
      ]
    }
  ]
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.4
      }
    }
  }
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-24 pb-16 px-4 sm:px-6"
    >
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Resume</h1>
          <p className="text-gray-400 max-w-2xl mx-auto mb-6">
            My professional experience, education, and skills.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              onClick={() => window.open('#')}
              onMouseEnter={textEnter}
              onMouseLeave={textLeave}
            >
              <FontAwesomeIcon icon={faDownload} className="mr-2" />
              Download PDF
            </Button>
            <Button
              variant="secondary"
              onClick={() => window.open('#', '_blank')}
              onMouseEnter={textEnter}
              onMouseLeave={textLeave}
            >
              <FontAwesomeIcon icon={faExternalLinkAlt} className="mr-2" />
              View Online
            </Button>
          </div>
        </motion.div>
        
        {/* Resume Paper */}
        <motion.div
          className="glass rounded-2xl p-8 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          onMouseEnter={textEnter}
          onMouseLeave={textLeave}
        >
          {/* Resume Header */}
          <div className="border-b border-gray-700 pb-6 mb-6">
            <h2 className="text-3xl font-bold">Ritik</h2>
            <p className="text-xl text-gray-300 mt-1">Full Stack Developer</p>
            <div className="mt-4 flex flex-wrap gap-4">
              <span className="text-gray-400">contact@ritik.com</span>
              <span className="text-gray-400">San Francisco, CA</span>
              <span className="text-gray-400">github.com/ritik</span>
            </div>
          </div>
          
          {/* Resume Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {resumeSections.map((section, index) => (
              <motion.div 
                key={index}
                variants={itemVariants}
                className="resume-section"
              >
                <h3 className="text-xl font-semibold mb-4 border-b border-gray-700 pb-2">
                  {section.title}
                </h3>
                
                {/* For sections with plain content */}
                {section.content && (
                  <p className="text-gray-300">{section.content}</p>
                )}
                
                {/* For sections with items (experience, education, certifications) */}
                {section.items && (
                  <div className="space-y-6">
                    {section.items.map((item, i) => (
                      <div key={i}>
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start">
                          <div>
                            <h4 className="text-lg font-medium">{item.title}</h4>
                            {item.company && <p className="text-gray-300">{item.company}</p>}
                            {item.institution && <p className="text-gray-300">{item.institution}</p>}
                            {item.issuer && <p className="text-gray-300">{item.issuer}</p>}
                          </div>
                          <p className="text-gray-400 mt-1 sm:mt-0">{item.period}</p>
                        </div>
                        
                        {item.duties && (
                          <ul className="mt-2 list-disc list-inside text-gray-300 space-y-1">
                            {item.duties.map((duty, j) => (
                              <li key={j}>{duty}</li>
                            ))}
                          </ul>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                
                {/* For skills section */}
                {section.categories && (
                  <div className="space-y-4">
                    {section.categories.map((category, i) => (
                      <div key={i}>
                        <h4 className="text-lg font-medium mb-2">{category.name}</h4>
                        <div className="flex flex-wrap gap-2">
                          {category.skills.map((skill, j) => (
                            <span 
                              key={j}
                              className="px-3 py-1 bg-white bg-opacity-5 rounded-full text-sm"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  )
}

export default Resume